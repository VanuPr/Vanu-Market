
// This file is deprecated and will be removed. Locations are now managed in the admin panel.
export const jharkhandDistricts = {};
